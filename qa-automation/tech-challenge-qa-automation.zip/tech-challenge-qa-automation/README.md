# QA Automation Technical Challenge

> Please write in this file:
> * Comments and clarifications about approaches or decisions.
> * Other tests cases and checks you would consider for the endpoints and language navigation.
> * Information about any failing tests, including possible reasons and suggestions on how to fix it.
