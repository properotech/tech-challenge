#!/bin/bash

echo 'Provide command line(s) to be executed to run your tests'
